package map;

import java.awt.image.BufferedImage;

/**
 * Created by johan on 2017-04-10.
 */
public class Tile {
	BufferedImage tile = null;
	boolean walkable = false;
}
