package game;

/**
 * Created by johan on 2017-04-10.
 */
public enum GameState {
	WaveStart,
	Wave,
	WaveEnd,
	WaveBreak, Winner, Loser
}
